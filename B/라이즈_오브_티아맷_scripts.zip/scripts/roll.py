"""Minimal CSPRNG dice roller following the ttrpg-dice-roller notation subset:
NdM, khN / klN, and +/- integer or dice terms. Usage:
  python3 roll.py LOGFILE "label|expr" "label|expr" ...
Appends each result as one JSON line to LOGFILE and prints it."""
import json, re, secrets, sys

TERM = re.compile(r'([+-]?)\s*(?:(\d*)d(\d+)(?:(kh|kl)(\d+))?|(\d+))')

def roll(expr):
    total, trace = 0, []
    for sign, n, m, k, kn, const in TERM.findall(expr.replace(' ', '')):
        s = -1 if sign == '-' else 1
        if const:
            total += s * int(const); trace.append(f"{sign or '+'}{const}"); continue
        n = int(n or 1); m = int(m)
        dice = [secrets.randbelow(m) + 1 for _ in range(n)]
        kept = sorted(dice, reverse=(k == 'kh'))[:int(kn)] if k else dice
        total += s * sum(kept)
        trace.append(f"{sign or '+'}{n}d{m}{k}{kn}{dice}->{sum(kept)}")
    return total, trace

log = sys.argv[1]
with open(log, 'a', encoding='utf-8') as f:
    for item in sys.argv[2:]:
        label, expr = item.split('|', 1)
        t, tr = roll(expr)
        nat = None
        if re.fullmatch(r'\s*(2d20k[hl]1|1?d20)\s*([+-]\s*\d+)?\s*', expr):
            nat = int(re.search(r'->(\d+)', tr[0]).group(1))
        rec = {"label": label, "expr": expr, "total": t, "nat20": nat, "trace": tr}
        f.write(json.dumps(rec, ensure_ascii=False) + '\n')
        print(f"{label:38s} {expr:14s} = {t:4d}" + (f"  (d20 {nat})" if nat else ''))
