"""문장 단위 치환을 적용한다. 바꿀 문장이 파일에 정확히 한 번 나올 때만 바꾼다.

사용: python3 apply_replacements.py 대상.md 치환목록.json

치환목록.json 형식: [["바꿀 문장", "새 문장"], ...]

이번 작업에서는 번역 검수 반영, 윤문, 서사 보강, 장 사이 다리 문장을 넣을 때
치환 목록을 스크립트 안에 직접 적어 같은 방식으로 돌렸다. 그 목록에는 본문이
그대로 들어 있어서, 여기서는 목록을 JSON 파일로 받도록 바꿨다.
"""
import json
import sys

path, reps_path = sys.argv[1], sys.argv[2]
s = open(path, encoding="utf-8").read()
for old, new in json.load(open(reps_path, encoding="utf-8")):
    n = s.count(old)
    if n != 1:
        sys.exit(f"중단: 바꿀 문장이 {n}번 나온다: {old[:40]}")
    s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("적용 완료")
