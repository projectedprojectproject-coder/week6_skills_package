# 라이즈 오브 티아맷 작업에 쓴 스크립트

DM 가이드, 플레이 기록, 소설판을 만들 때 쓴 스크립트를 모았다.

## 파일

| 파일 | 하는 일 | 상태 |
|---|---|---|
| roll.py | 주사위를 굴리고 결과를 JSON Lines 로그에 남긴다. Python secrets 모듈의 암호학적 난수를 쓴다 | 작업에 쓴 파일 그대로 |
| build_docx.js | 마크다운을 A4 Word 문서로 만든다. 제목, 표, 목록, 쪽 번호를 처리한다 | 작업에 쓴 파일 그대로. 첫 줄 설명 주석만 고치고 낡은 주석 한 줄을 지웠다 |
| make_roll_appendix.py | 굴림 로그를 부록 B의 표로 바꾼다 | 작업 중 인라인으로 돌린 코드를 파일로 옮겼다. 뒤에 붙던 출처 목록은 뺐다 |
| verify_edits.py | 고치기 전후를 비교해 변경률, 숫자, 제목, 대사, 이름, 표현 빈도를 확인한다 | 단계마다 따로 돌린 검사를 한 파일로 모았다 |
| apply_replacements.py | 정확히 한 번 나오는 문장만 골라 바꾼다 | 같은 방식으로 돌린 치환 코드를, 치환 목록을 JSON으로 받게 바꿨다 |
| data/roll_log.jsonl | 플레이 기록에 쓴 굴림 269회와 무효 사유 메모 4줄 | 작업 결과 그대로 |

## 쓰는 법

주사위 굴리기. 한 번에 여러 개를 "이름|표기" 형식으로 넘긴다. 지원하는 표기는 NdM, khN, klN, 정수 더하기와 빼기다.

```bash
python3 roll.py log.jsonl "브람 공격|1d20+8" "피해|2d6+5" "그룹 은신 최저|4d20kl1+3"
```

굴림 로그를 부록 표로 만들기.

```bash
python3 make_roll_appendix.py data/roll_log.jsonl > appendix_b.md
```

Word 문서 만들기. npm 패키지 docx가 필요하다. 부록이 없으면 빈 파일을 두 번째 인자로 넘긴다.

```bash
npm install docx
touch empty.md
node build_docx.js novel.md empty.md 소설판.docx
```

PDF로 바꾸기. 이번 작업에서는 docx 스킬에 들어 있는 LibreOffice 도우미를 썼다.

```bash
python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf 소설판.docx
```

LibreOffice가 따로 설치되어 있으면 아래 명령도 같다.

```bash
soffice --headless --convert-to pdf 소설판.docx
```

윤문 결과 확인하기.

```bash
python3 verify_edits.py novel_before.md novel_after.md --names 브람,세라,카엘,미라 --patterns 그녀,그러나
```

문장 치환하기.

```bash
python3 apply_replacements.py novel.md replacements.json
```

## 알아 둘 점

- 이번 작업에서 humanize-korean과 ttrpg-dice-roller 스킬에는 원래 스크립트가 들어 있지 않았다. roll.py와 verify_edits.py는 그 자리를 대신하려고 새로 만든 것이며, 스킬에 원래 있어야 할 스크립트와는 다르다.
- build_docx.js는 한글에 Noto Serif CJK KR 글꼴을 쓴다. 이 글꼴이 없는 컴퓨터에서는 다른 글꼴로 바뀌어 보일 수 있다.
- build_docx.js는 이번 문서들에 나온 마크다운만 처리한다. 굵은 글씨, 링크, 표 안의 줄바꿈 같은 서식은 처리하지 않는다.
