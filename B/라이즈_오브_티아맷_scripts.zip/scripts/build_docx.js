// Markdown 파일을 A4 Word 문서(.docx)로 만든다. 사용: node build_docx.js 본문.md 부록.md 출력.docx (부록이 없으면 빈 파일을 넘긴다)
const fs = require('fs');
const d = require('docx');
const [,, guidePath, reviewPath, outPath] = process.argv;

const LATIN = 'Times New Roman', KO = 'Noto Serif CJK KR';
const font = { ascii: LATIN, hAnsi: LATIN, eastAsia: KO, cs: LATIN };
const run = (text, o = {}) => new d.TextRun({ text, font, size: o.size || 24, bold: o.bold });
const CONTENT_W = 11906 - 2 * 1440; // A4 width minus 1-inch margins
const border = { style: d.BorderStyle.SINGLE, size: 4, color: '999999' };
const borders = { top: border, bottom: border, left: border, right: border };

function cell(text, w, header) {
  return new d.TableCell({
    width: { size: w, type: d.WidthType.DXA }, borders,
    shading: header ? { type: d.ShadingType.CLEAR, color: 'auto', fill: 'E8E8E8' } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new d.Paragraph({ children: [run(text, { size: 21, bold: header })] })],
  });
}
function table(rows) {
  const cols = rows[0].length;
  // widths proportional to average text length per column, each at least 18%
  const avg = [...Array(cols)].map((_, j) => rows.reduce((a, r) => a + r[j].length, 0) / rows.length);
  let share = avg.map(a => a / avg.reduce((x, y) => x + y, 0));
  share = share.map(x => Math.max(x, 0.18)); const tot = share.reduce((x, y) => x + y, 0);
  const widths = share.map(x => Math.round(CONTENT_W * x / tot));
  widths[cols - 1] = CONTENT_W - widths.slice(0, cols - 1).reduce((a, b) => a + b, 0);
  return new d.Table({
    width: { size: CONTENT_W, type: d.WidthType.DXA }, columnWidths: widths,
    rows: rows.map((r, i) => new d.TableRow({ tableHeader: i === 0, children: r.map((t, j) => cell(t, widths[j], i === 0)) })),
  });
}

function convert(md, isFirst) {
  const out = [];
  const lines = md.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!l.trim() || /^---$/.test(l.trim())) continue;
    if (l.startsWith('|')) {
      const rows = [];
      while (i < lines.length && lines[i].startsWith('|')) {
        const cells = lines[i].slice(1, -1).split('|').map(s => s.trim());
        if (!cells.every(c => /^-+$/.test(c))) rows.push(cells);
        i++;
      }
      i--;
      out.push(table(rows), new d.Paragraph({ children: [] }));
    } else if (l.startsWith('# ')) {
      const t = l.slice(2);
      out.push(isFirst
        ? new d.Paragraph({ alignment: d.AlignmentType.CENTER, spacing: { after: 360, line: 480 }, children: [run(t, { size: 44, bold: true })] })
        : new d.Paragraph({ heading: d.HeadingLevel.HEADING_1, pageBreakBefore: true, spacing: { after: 240 }, children: [run(t, { size: 32, bold: true })] }));
    } else if (l.startsWith('## ')) {
      out.push(new d.Paragraph({ heading: isFirst ? d.HeadingLevel.HEADING_1 : d.HeadingLevel.HEADING_2, spacing: { before: 360, after: 160 }, children: [run(l.slice(3), { size: isFirst ? 32 : 28, bold: true })] }));
    } else if (l.startsWith('### ')) {
      out.push(new d.Paragraph({ heading: d.HeadingLevel.HEADING_2, spacing: { before: 280, after: 120 }, children: [run(l.slice(4), { size: 28, bold: true })] }));
    } else if (l.startsWith('- ')) {
      out.push(new d.Paragraph({ numbering: { reference: 'bul', level: 0 }, children: [run(l.slice(2))] }));
    } else if (/^\d+\. /.test(l)) {
      out.push(new d.Paragraph({ numbering: { reference: 'num', level: 0 }, children: [run(l.replace(/^\d+\. /, ''))] }));
    } else {
      out.push(new d.Paragraph({ spacing: { after: 120 }, children: [run(l)] }));
    }
  }
  return out;
}

const doc = new d.Document({
  styles: { default: { document: { run: { font, size: 24 }, paragraph: { spacing: { line: 300 } } } } },
  numbering: { config: [
    { reference: 'bul', levels: [{ level: 0, format: d.LevelFormat.BULLET, text: '•', alignment: d.AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
    { reference: 'num', levels: [{ level: 0, format: d.LevelFormat.DECIMAL, text: '%1.', alignment: d.AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
  ] },
  sections: [{
    properties: { page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    footers: { default: new d.Footer({ children: [new d.Paragraph({ alignment: d.AlignmentType.CENTER, children: [new d.TextRun({ children: [d.PageNumber.CURRENT], font, size: 18 })] })] }) },
    children: [...convert(fs.readFileSync(guidePath, 'utf8'), true), ...convert(fs.readFileSync(reviewPath, 'utf8'), false)],
  }],
});
d.Packer.toBuffer(doc).then(b => fs.writeFileSync(outPath, b));
