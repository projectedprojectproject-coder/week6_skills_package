"""굴림 로그(JSON Lines)를 플레이 기록 부록 B의 마크다운 표로 만든다.

사용: python3 make_roll_appendix.py data/roll_log.jsonl > appendix_b.md

로그의 label이 NOTE인 줄은 번호 없이 "메모" 행으로 넣는다.
이번 작업에서는 이 표 뒤에 출처 목록을 이어 붙였다. 출처 부분은 여기서 뺐다.
"""
import json
import sys

print("\n## 부록 B: 전체 굴림 기록\n")
print("굴림 순서대로 적었다. 주사위 열은 굴림기가 남긴 개별 눈 값이다. "
      "메모 행은 굴린 뒤 무효가 된 굴림과 그 이유다.\n")
print("| 번호 | 굴림 | 표기 | 결과 | 주사위 |")
print("|---|---|---|---|---|")
n = 0
for line in open(sys.argv[1], encoding="utf-8"):
    r = json.loads(line)
    if r["label"] == "NOTE":
        print(f"| 메모 | {r['expr']} | | | |")
        continue
    n += 1
    dice = " ".join(t.split("->")[0].lstrip("+") for t in r["trace"] if "d" in t)
    print(f"| {n} | {r['label']} | {r['expr']} | {r['total']} | {dice} |")
