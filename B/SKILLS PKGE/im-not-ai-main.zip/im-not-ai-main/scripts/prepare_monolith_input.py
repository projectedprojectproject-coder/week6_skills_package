#!/usr/bin/env python3
"""Humanize KR v2.0 — monolith input shim.

Pre-processes user input by computing quantitative metrics (v1.6 8지표 +
v2.0 카운트형 지표) and prepending the result to the text the monolith
agent reads. The monolith keeps its 4-tool-call cap (Read input + Read
rules + Write final + Write summary) because the metrics block is folded
into the same input file.

Inputs:
  --run-dir DIR     existing run directory containing 01_input.txt
  --text STR        ad-hoc text; if --run-dir is omitted, a new run dir
                    `_workspace/<YYYY-MM-DD>-NNN/` is created and
                    01_input.txt written.
  --genre STR       essay|column|report|blog|abstract|... (default: essay)
  --diagnosis PATH  optional diagnosis text prepended before the metrics
                    block (정밀 3콜 구조의 진단 1콜 산출물 자리)
  --chunk           장문 청킹 모드. 01_input.txt 를 손실 없이 청크로 나눠
                    청크별 01_chunk_{NN}_input_with_metrics.txt 와
                    chunk_manifest.json 을 만든다. 경계 결정은 100% 코드
                    (LLM 개입 0). 재조립은 scripts/reassemble_chunks.py.

Outputs (in {run_dir}):
  00_metrics.json             — full compute_all() output (or error stub)
  01_input.txt                — original text (created if --text used)
  01_input_with_metrics.txt   — combined file the monolith Reads
  00_metrics.error            — only on graceful-degrade fallback

Hard rules:
  - stdlib only (argparse/json/os/sys/datetime/pathlib/traceback)
  - never modify the original text body inside the combined file
  - on metrics failure, write the combined file *without* the score block
    so the monolith degrades to v1.5 behaviour automatically.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import traceback
from datetime import date
from pathlib import Path

# Resolve project layout. This file lives at:
#   {project_root}/scripts/prepare_monolith_input.py
# metrics.py is at:
#   {project_root}/skills/humanize-korean/references/metrics.py
HERE = Path(__file__).resolve().parent
PROJECT_ROOT = HERE.parent
_PLUGIN_REFS = PROJECT_ROOT / "skills" / "humanize-korean" / "references"
_CODEX_REFS = PROJECT_ROOT / "references"
METRICS_DIR = _PLUGIN_REFS if _PLUGIN_REFS.is_dir() else _CODEX_REFS

# Make metrics.py importable without polluting global state.
sys.path.insert(0, str(METRICS_DIR))
# v2.0 우선 import — compute_all 별칭으로 v1.6 호환. metrics_v2 부재·로드 실패 시
# v1.6 metrics fallback. graceful degrade로 monolith 동작은 항상 보장.
try:
    import metrics_v2 as _metrics_mod  # type: ignore  # v2.0 (post-editese 14 metric)
except Exception:  # pragma: no cover
    try:
        import metrics as _metrics_mod  # type: ignore  # v1.6 fallback
    except Exception:
        _metrics_mod = None


# ---------------------------------------------------------------------------
# Run directory discovery / creation
# ---------------------------------------------------------------------------


def _next_run_dir(workspace: Path, session_tag: str | None = None) -> Path:
    """Allocate _workspace/<today>-NNN[-<tag>]/ with the smallest free NNN.

    **확인과 생성을 한 번에 한다.** 예전에는 `exists()` 로 빈 자리를 보고 호출부가
    나중에 mkdir 했다. 그 사이에 다른 프로세스가 같은 이름을 잡으면 두 실행이 한
    디렉터리를 공유한다 — 뒤에 온 쪽이 앞선 쪽의 `01_input.txt` 를 덮어쓰고,
    게이트는 *남의 원문과 내 윤문본*을 비교해 있지도 않은 제목·인용이 사라졌다며
    ABORT 를 낸다. 윤문본 자체는 멀쩡하므로 원인을 찾기가 특히 어렵다.

    `session_tag` 를 주면 이름 뒤에 붙어 세션끼리 번호도 겹치지 않는다.
    `YYYY-MM-DD-` 접두어는 그대로라 기존 Glob 패턴·정렬은 영향받지 않는다.
    """
    workspace.mkdir(parents=True, exist_ok=True)
    today = date.today().isoformat()
    tag = f"-{session_tag}" if session_tag else ""
    for n in range(1, 1000):
        candidate = workspace / f"{today}-{n:03d}{tag}"
        try:
            candidate.mkdir(parents=True, exist_ok=False)
            return candidate
        except FileExistsError:
            continue
    raise SystemExit(
        f"run dir 자리를 못 찾았다: {workspace}/{today}-NNN{tag} 가 999개까지 찼다"
    )


def _resolve_run_dir(
    run_dir_arg: str | None, text_arg: str | None, session_tag: str | None = None
) -> Path:
    """상대 경로는 **cwd** 기준으로 푼다.

    이전에는 PROJECT_ROOT(설치 저장소 루트) 기준이었다. SKILL.md 는 "모든 경로는
    cwd 기준"이라고 지시하는데 스크립트는 저장소 루트에서 찾으니, 심링크로 설치해
    사용자 작업 디렉터리에서 스킬을 부르는 정상 흐름이 첫 실행부터 실패했다.
    (저장소 루트에서 돌릴 때는 cwd == PROJECT_ROOT 라 동작이 같다.)

    빈 디렉터리도 남기지 않는다 — 예전에는 존재 확인 전에 mkdir 을 해서, 실패할
    때마다 설치 위치에 빈 `_workspace/{run_id}/` 가 쌓였다. 새로 만드는 경우
    (--text)에만 생성한다.
    """
    if run_dir_arg:
        rd = Path(run_dir_arg)
        if not rd.is_absolute():
            rd = Path.cwd() / rd
        if text_arg is not None:
            rd.mkdir(parents=True, exist_ok=True)  # 입력을 쓸 것이므로 생성
        elif not rd.is_dir():
            raise SystemExit(
                f"run-dir not found: {rd}\n"
                "  (상대 경로는 현재 디렉터리 기준으로 해석됩니다. "
                "--text 를 주면 새로 만듭니다.)"
            )
        return rd
    if text_arg is None:
        raise SystemExit("Either --run-dir or --text is required")
    workspace = Path.cwd() / "_workspace"
    return _next_run_dir(workspace, session_tag)  # 생성까지 원자적으로 끝난다


# ---------------------------------------------------------------------------
# 텍스트 위생 — 보이지 않는 오염 문자 정리 (결정적, LLM 콜 0회)
# ---------------------------------------------------------------------------
#
# 왜 shim 에서 하는가: 01_input.txt 가 이후 모든 단계의 기준선이기 때문이다.
# 특히 macOS 경유 텍스트의 NFD 분해 한글은 눈에 안 보이지만 치명적이다 —
# 윤문 결과는 NFC 로 나오므로 변경률 게이트(철칙 #4)가 "전 글자 변경"으로 읽고
# 50% 초과 강제 중단에 걸린다. 여기서 한 번 정규화해 두면 게이트·diff·글자수가
# 전부 같은 기준을 쓰게 된다.
#
# 이 처리는 AI 워터마크와 무관하다 (scripts/sanitize_text.py 상단 주석 참조).

try:
    import sanitize_text as _sanitize_mod
except Exception:  # noqa: BLE001 — 위생 처리 실패는 파이프라인을 막지 않는다.
    _sanitize_mod = None


def _load_input(input_path: Path, run_dir: Path, enabled: bool) -> str:
    """01_input.txt 를 읽고, 켜져 있으면 위생 처리해 제자리에 반영한다."""
    text = input_path.read_text(encoding="utf-8")
    if not enabled or _sanitize_mod is None:
        return text
    try:
        cleaned, report = _sanitize_mod.sanitize(text)
    except Exception:  # noqa: BLE001 — graceful degrade.
        return text
    if report.changed:
        input_path.write_text(cleaned, encoding="utf-8")
        (run_dir / "00_sanitize.json").write_text(
            json.dumps(report.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"sanitize={report.summary}")
    return cleaned if report.changed else text


# ---------------------------------------------------------------------------
# Route hint — shim이 "손댈 양"을 판정해 경로를 권고한다
# ---------------------------------------------------------------------------
#
# 배경: 9,817자 실측 run(_workspace/2026-07-18-001)은 어휘·피동 카운트형 티가
# 전부 0이고 구조 티(ending_comma z=+6.29)만 있는 "잘 쓴 글"이었는데도 최중량
# 6청크 경로를 돌아 610K 토큰을 썼다. 같은 글 단일 콜은 134K에 품질 동등.
# shim은 이미 그 판정에 필요한 점수를 전부 내고 있으므로, 여기서 route_hint 를
# 함께 산출해 오케스트레이터가 경로를 정하게 한다. route_hint 는 **권고**다 —
# 사용자·오케스트레이터가 무시할 수 있고, 산출 실패 시 없는 채로 진행한다.
#
# 3-tier 판정 (전부 결정적 · 실측 기반):
#   light    — 카운트형 어휘·피동 티 합 ≤ 2 AND risk_band low~medium.
#              이미 잘 쓴 글. 단일 콜·최소 파이프라인 권장.
#   standard — 그 외 (티가 섞여 있거나, 카운트형 0이어도 구조 지표로 risk high).
#              진단 + 단일 윤문 권장. 실측 글(카운트 0·risk high)이 여기 온다.
#   heavy    — risk high AND 카운트형 티 합 ≥ 8 (AI 슬롭 밀집),
#              또는 초장문(> CHUNK_RECOMMEND_MIN_CHARS). 진단 + 청킹 권장.
#
# 카운트형 티 = v1.6 conclusion_pivot·safe_balance + v2.0 이중피동·에의해피동·
# have/make직역·이중조사. 전부 정수 카운트라 baseline calibration 없이도 안정적.
# 밀도·z-score 지표는 판정에서 제외 — v2 baseline 이 placeholder 라 불안정하다.

ROUTE_LIGHT_MAX_TELLS = 2
ROUTE_HEAVY_MIN_TELLS = 8
# 초장문 기준. 아래 청킹 섹션의 CHUNK_RECOMMEND_MIN_CHARS 가 이 값을 공유한다
# — "heavy 판정"과 "청킹이 의미 있는 최소 분량"은 같은 실증에서 나온 한 기준.
ROUTE_HEAVY_MIN_CHARS = 15000

_ROUTE_TELL_KEYS_V16 = ("conclusion_pivot_count", "safe_balance_count")
_ROUTE_TELL_KEYS_V2 = (
    "double_passive_count",
    "by_passive_count",
    "have_make_literal_count",
    "double_particle_count",
)

# ── v2.6 신형 티 계수 (라우터 실명 방지) ─────────────────────────────
# 실사고: 저자 추천사(1,124자)가 은유 관통 4회·감각 술어 2회·분열문을 안고도
# risk low·tells 0으로 light("잘 쓴 글, 최소 수정")에 배정됐다. 위 카운트 키가
# 전부 v1.6 시절 지표라 v2.6에서 채굴한 티를 하나도 못 세기 때문이다 —
# 라우터가 못 보는 티는 어떤 경로에서도 고쳐지지 않는다(light는 최소 수정 지시).
# taxonomy v2.6 채택분 중 정규식화 가능한 것을 직접 센다. 사전은 quick-rules와
# 동일 어휘(단일 출처는 아니지만 갱신 시 함께 볼 것 — D-8~14·A-20·F-7).
import re as _re

_V26_ROUTE_PATTERNS = (
    ("분열문(D-8)", _re.compile(r"(?:필요|중요)한\s*것은|(?:문제는|핵심은|관건은|답은)\s+[^.?!\n]{0,50}(?:점이다|것이다|데\s*있다)")),
    ("이유다(D-10)", _re.compile(r"이유(?:다|이다|입니다)\.")),
    ("시간지평(D-11)", _re.compile(r"(?:^|[.!?]\s+)(?:향후|앞으로는?|중?장기적으로는?)(?![가-힣])", _re.M)),
    ("과제슬롯(D-12)", _re.compile(r"과제도\s*(?:남아\s*있다|남았다|뚜렷하다)|한계도\s*분명하다|아쉬운\s*점도\s*있다")),
    ("은유가족(D-14)", _re.compile(r"잠식|흡수(?:하|되)|짓누르|삼키|갉아먹|청구서|성적표|대가를\s*치|과실[을이]|씨앗|뿌리내리|청사진|주춧돌|짊어지|신호탄|적신호")),
    ("감각술어(D-14b)", _re.compile(r"(?:진단|경고|분석|통계|현실|숫자|전망|결론)[은는이가]\s*(?:서늘하|아프|차갑|뜨겁|묵직하|섬뜩하)")),
    ("피동진행(A-20)", _re.compile(r"(?:되|지)고\s*있(?:다|으며|고|는)")),
    ("범용동사(F-7)", _re.compile(r"(?:확대|강화|개선|확보|마련|구축)(?:해야|하[여어]야|가\s*필요)")),
)

# 관통 은유 — 은유성 동사 어근이 문서에서 3회 이상 반복(가족 사전 밖이어도).
# ⚠️ 한국어 활용에서 어근이 축약된다 — "쥘"(쥐+ㄹ)은 "쥐"와 다른 음절이라 어근만 매칭하면
# 놓친다(실사례: 쥐고·쥐여주는·쥘 3회 중 2회만 집계돼 역치 미달). 축약형을 함께 든다.
_RUNNING_METAPHOR = _re.compile(r"(쥐|쥘|움켜쥐|끌어안|짊어지|떠받치|끌고\s*가|붙들)")
_METAPHOR_ROOT_ALIAS = {"쥘": "쥐"}


def count_v26_tells(text: str) -> tuple[int, dict]:
    """v2.6 신형 티를 결정적으로 센다. (합계, 항목별) 반환."""
    per: dict[str, int] = {}
    total = 0
    for name, rx in _V26_ROUTE_PATTERNS:
        n = len(rx.findall(text))
        if n:
            per[name] = n
            total += n
    run = {}
    for m in _RUNNING_METAPHOR.finditer(text):
        root = _METAPHOR_ROOT_ALIAS.get(m.group(1), m.group(1))
        run[root] = run.get(root, 0) + 1
    for root, n in run.items():
        if n >= 3:
            per[f"관통은유({root})"] = n
            total += n
    return total, per


def compute_route_hint(metrics_obj: dict) -> dict:
    """metrics_obj(compute_all 산출)로부터 route_hint 권고를 산출한다.

    반환 dict 는 metrics_obj 에 update 해서 00_metrics.json 에 함께 실린다.
    입력이 부분적이어도(키 누락) 죽지 않고 보수적으로 standard 로 수렴한다.
    """
    m = metrics_obj.get("metrics") or {}
    v2 = metrics_obj.get("v2_metrics") or {}
    tells = 0
    for key in _ROUTE_TELL_KEYS_V16:
        tells += int(m.get(key) or 0)
    for key in _ROUTE_TELL_KEYS_V2:
        tells += int(v2.get(key) or 0)
    v26_total, v26_per = count_v26_tells(str(metrics_obj.get("_text") or ""))
    tells += v26_total
    chars = int(metrics_obj.get("char_count") or 0)
    risk = metrics_obj.get("risk_band", "unknown")

    if chars > ROUTE_HEAVY_MIN_CHARS:
        hint = "heavy"
        reason = (
            f"{chars:,}자 초장문(>{ROUTE_HEAVY_MIN_CHARS:,}) — 진단 + 청킹 권장"
        )
    elif risk == "high" and tells >= ROUTE_HEAVY_MIN_TELLS:
        hint = "heavy"
        reason = (
            f"risk_band high + 카운트형 티 {tells}건 — AI 슬롭 밀집, "
            f"진단 + 청킹 권장"
        )
    elif tells <= ROUTE_LIGHT_MAX_TELLS and risk in ("low", "medium"):
        hint = "light"
        reason = (
            f"카운트형 어휘·피동 티 {tells}건 · risk_band {risk} — "
            f"이미 잘 쓴 글, 단일 콜·최소 파이프라인 권장"
        )
    else:
        hint = "standard"
        reason = (
            f"카운트형 티 {tells}건 · risk_band {risk} — 진단 + 단일 윤문 권장"
        )
    return {
        "route_hint": hint,
        "route_reason": reason,
        "route_signals": {
            "lexical_tell_count": tells,
            "v26_tells": v26_per,
            "risk_band": risk,
            "char_count": chars,
        },
    }


# ---------------------------------------------------------------------------
# Combined-file rendering
# ---------------------------------------------------------------------------


def _fmt_z(z: float | None) -> str:
    if z is None:
        return "n/a"
    sign = "+" if z >= 0 else ""
    return f"z={sign}{z:.2f}"


# 단순화(simplification) 축 지표는 **낮을 때** AI 티다 — baseline 이 직접 그렇게
# 적어 둔다(`"interpretation": "low = AI-like (repetition)"`). 그런데 마커가 z 를
# 부호 그대로 읽어 **가장 어휘가 풍부한(= 가장 사람다운) 글에 "★ S1 트리거"** 를
# 붙이고 있었다. 모델은 그 표기를 보고 손댈 곳을 찾는다(PR #94 지적).
# 간섭(interference)·정규화(normalisation) 축은 높을 때 AI 티라 그대로 둔다.
_INVERTED_METRICS = frozenset(
    {
        "lexical_diversity",
        "lexical_diversity_ttr",
        "lexical_density",
        "ending_diversity",
    }
)


def _z_marker(z: float | None, key: str | None = None) -> str:
    """Emit a small star for values clearly in the AI band.

    ``key`` 가 단순화 축 지표면 부호를 뒤집어 판정한다. 키를 주지 않으면
    기존 동작(높을수록 AI 티)을 유지한다.
    """
    if z is None:
        return ""
    if key in _INVERTED_METRICS:
        z = -z
    if z >= 1.5:
        return "  ★ S1 트리거"
    if z >= 1.0:
        return "  · S2 시그널"
    return ""


# v2.0 카운트형 지표 — baseline 없이 원값만으로 유용한 지표들.
# (key, 한국어 라벨, taxonomy ID, 포맷) — ID는 ai-tell-taxonomy.md 본진.
_V2_COUNT_METRICS = (
    ("double_passive_count", "이중 피동", "A-8", "{:d}"),
    ("by_passive_count", "~에 의해 피동", "A-9", "{:d}"),
    ("pronoun_density", "인칭 대명사 밀도", "A-16", "{:.3f}"),
    ("have_make_literal_count", "have/make 직역", "A-7", "{:d}"),
    ("double_particle_count", "이중 조사 결합", "A-19", "{:d}"),
    ("relative_clause_nesting", "관형절 3중+ 중첩 문장 수", "A-18", "{:d}"),
    ("deul_overuse_rate", "'-들' 남용률", "A-17 hold", "{:.3f}"),
)


def _render_v2_counts(metrics_obj: dict) -> list[str]:
    """v2.0 카운트형 지표 원값 렌더.

    v2 z-score는 렌더하지 않는다 — baseline_v2.json 70셀 전부 placeholder
    (추정치)라 calibration 전까지 해석 보류. 카운트/밀도 원값은 baseline
    없이도 그 자체로 윤문 근거가 된다.
    """
    v2 = metrics_obj.get("v2_metrics")
    if not v2:
        return []
    lines: list[str] = []
    lines.append("[v2.0 카운트형 지표 — 원값 / baseline calibration 전 z-score 해석 보류]")
    for key, label, tell_id, fmt in _V2_COUNT_METRICS:
        val = v2.get(key)
        if val is None:
            lines.append(f"- {key}: n/a")
            continue
        if fmt == "{:d}":
            rendered = fmt.format(int(val))
        else:
            rendered = fmt.format(float(val))
        lines.append(f"- {key} ({label}, 본진 {tell_id}): {rendered}")
    lines.append("- 카운트 > 0 지표는 해당 본진 ID 처방(quick-rules.md·taxonomy)과 교차 확인 후 윤문할 것.")
    lines.append("")
    return lines


def _render_block(metrics_obj: dict) -> str:
    m = metrics_obj.get("metrics", {})
    z = metrics_obj.get("z_scores", {})
    ev = metrics_obj.get("evidence", {})
    pivots = ev.get("conclusion_pivots") or []
    safe = ev.get("safe_balances") or []

    lines: list[str] = []
    lines.append("[정량 사전 점수 v2.0 — v1.6 8지표(KatFish baseline) + v2.0 카운트형]")
    lines.append(
        f"risk_band: {metrics_obj.get('risk_band', 'unknown')}  "
        f"(score {metrics_obj.get('risk_score', 0)})"
    )
    if metrics_obj.get("route_hint"):
        lines.append(
            f"route_hint: {metrics_obj['route_hint']}  "
            f"(권고 — 사용자·오케스트레이터가 무시 가능)"
        )
        lines.append(f"route_reason: {metrics_obj.get('route_reason', '')}")
    lines.append(f"genre: {metrics_obj.get('genre', 'essay')}")
    lines.append(f"char_count: {metrics_obj.get('char_count', 0)}")
    if metrics_obj.get("warning"):
        lines.append(f"warning: {metrics_obj['warning']}")
    lines.append("")
    lines.append("[v1.6 지표]")

    def row(key: str, value_fmt: str, with_z: bool = True, suffix: str = "") -> str:
        val = m.get(key)
        if val is None:
            return f"- {key}: n/a"
        z_part = ""
        if with_z:
            z_part = f"  ({_fmt_z(z.get(key))} vs {metrics_obj.get('genre','essay')} 인간 baseline){_z_marker(z.get(key), key)}"
        return f"- {key}: {value_fmt.format(val)}{z_part}{suffix}"

    lines.append(row("comma_inclusion_rate", "{:.2f}"))
    lines.append(row("comma_usage_rate", "{:.2f}"))
    lines.append(row("ending_comma_rate", "{:.2f}"))
    lines.append(row("comma_segment_length", "{:.2f}"))

    pivot_suffix = f"  (lexicon 매치: {', '.join(repr(p) for p in pivots)})" if pivots else ""
    lines.append(
        f"- conclusion_pivot_count: {int(m.get('conclusion_pivot_count', 0))}{pivot_suffix}"
    )
    safe_suffix = f"  (lexicon 매치: {', '.join(repr(s) for s in safe)})" if safe else ""
    lines.append(
        f"- safe_balance_count: {int(m.get('safe_balance_count', 0))}{safe_suffix}"
    )
    lines.append(row("hanja_nominalizer_density", "{:.3f}"))
    lines.append(row("lexical_diversity", "{:.2f}"))
    lines.append("")
    lines.extend(_render_v2_counts(metrics_obj))
    lines.append("[근거 사용 가이드]")
    lines.append("- 위 점수는 *근거 보조*다. 단독 판정 금지(보고서 명시).")
    lines.append("- z>1.0 지표는 quick-rules.md S1·S2 패턴과 교차 확인 후 윤문할 것.")
    lines.append("- ending_comma_rate가 ★ S1 트리거인 경우 C-11(연결어미 뒤 쉼표) 우선 손질.")
    lines.append("- conclusion_pivot 매치 토큰은 D-1·H-1 처방 적용 대상.")
    lines.append("")
    return "\n".join(lines)


def _render_combined(
    text: str, metrics_obj: dict | None, diagnosis: str | None = None
) -> str:
    parts: list[str] = []
    if diagnosis:
        parts.append("[진단]")
        parts.append(diagnosis.rstrip("\n"))
        parts.append("[진단 끝]")
        parts.append("")
    if metrics_obj is not None:
        parts.append(_render_block(metrics_obj))
    parts.append("[원문 시작]")
    parts.append(text.rstrip("\n"))
    parts.append("[원문 끝]")
    parts.append("")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# --chunk mode: 손실 없는 결정적 분할 (v2.0.1 — fast+청킹으로 strict 승급 폐지)
# ---------------------------------------------------------------------------
#
# 불변식 (최상위): 모든 청크(passthrough 포함)를 순서대로 이으면 원문과
# 공백·개행까지 정확히 일치한다. 이를 위해 청크는 문자열 조각이 아니라
# 원문 offset [start, end) 구간으로 정의하고, 쓰기 전에 self-check 한다.
#
# 경계 우선순위:
#   1. 헤딩 줄 앞 강제 컷 — 헤딩은 반드시 다음 청크의 첫 줄이 된다.
#      (웹앱 imnotai.kr 의 "제목이 본문과 한 청크로 묶여 병합 윤문" 버그 차단.
#       연속 헤딩 런 사이에는 컷하지 않아 청크가 헤딩으로 끝나는 일이 없다.)
#   2. 빈 줄(\n{2,}) 문단 경계 그리디 패킹 (목표 TARGET_CHUNK_CHARS).
#   3. 한 문단이 상한 초과 시에만 문장 경계 폴백.
#   4. 문서 말미 각주 블록은 passthrough 청크로 태깅해 윤문 대상에서 제외.
#
# 청크 크기: 목표 7,000 / 상한 9,000 (v2.1 상향 — 종전 3,000/4,000).
# 근거: 9,817자 실측 run(_workspace/2026-07-18-001)에서 6청크 정밀 파이프라인이
# 610K 토큰(7콜)을 쓴 반면 단일 콜은 134K로 품질 동등(ending_comma_rate 0.09/0.08)
# — 폭발 원인은 콜마다 룰북·컨텍스트 재로드이므로 청크 수 자체를 줄여야 한다.
# 단일 콜이 1만자를 검증된 품질로 처리하므로 청크도 그 급으로 키운다. 웹앱의
# 1800은 flash-lite 전제라 이식 금지 — 큰 모델은 대구·리듬 같은 문단 횡단
# 신호를 잡아야 하므로 청크가 커야 한다.
#
# 청킹 자체는 CHUNK_RECOMMEND_MIN_CHARS(15,000자) 초과 장문에서만 의미가 있다
# — 그 미만은 단일 콜 실증 범위라 run_chunk_mode 가 비권장 경고를 남긴다(권고,
# 강제 아님). 헤딩 강제 컷은 무결성 불변식이라 유지되므로, 헤딩이 촘촘한
# 문서는 크기 임계와 무관하게 섹션 수만큼 청크가 나온다 — 그런 문서일수록
# 단일 콜 경로(route_hint)가 답이다.

TARGET_CHUNK_CHARS = 7000
MAX_CHUNK_CHARS = 9000
# 문장 경계 폴백 트리거 겸 "쪼갤 수 없는 통짜 런" 경고 기준. 상한(9,000)과
# 분리해 종전 4,000을 유지한다 — 재조립 유실 검증(청크 절반 미만 감지)의
# granularity 와 종결부호 없는 초장 런 경고 감도를 보존하기 위함. 폴백으로
# 잘게 난 조각은 어차피 target 까지 그리디 재패킹되므로 콜 수는 늘지 않는다.
SENT_SPLIT_TRIGGER_CHARS = 4000
CHUNK_RECOMMEND_MIN_CHARS = ROUTE_HEAVY_MIN_CHARS

HEADING_LINE_RE = re.compile(
    r"^(#{1,6}\s"
    r"|[ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ]+\."
    r"|\d+\.\s"
    r"|\d+\)\s"
    r"|제\s*\d+\s*[장절편]"
    r"|[가나다라마바사아자차카타파하]\.\s"
    r"|\([0-9가-힣]+\))"
)
# 각주 정의 줄. \d+\) 는 헤딩 정규식과 겹치지만 각주 판정은 문서 말미의
# 연속 블록에만 적용되고 그 구간은 본문 청킹에서 제외되므로 충돌 없음.
FOOTNOTE_LINE_RE = re.compile(r"^(?:\d+\)\s|\[\d+\]\s)")

_PARA_SEP_RE = re.compile(r"\n{2,}")
# 문장 경계: 종결 부호(+닫는 따옴표류) 뒤 공백. 컷은 공백 런 끝 = 다음 문장 시작.
_SENT_END_RE = re.compile(r"[.!?。！？…]['\"”’』」)\]]*\s+")


class ChunkingError(RuntimeError):
    """손실 없는 분할 불변식 위반 — 즉시 중단해야 하는 fidelity 사고."""


def _line_spans(text: str) -> list[tuple[int, int]]:
    """개행 포함 줄 구간 [(start, end), ...]. 이으면 원문과 일치."""
    spans: list[tuple[int, int]] = []
    pos = 0
    n = len(text)
    while pos < n:
        nl = text.find("\n", pos)
        if nl == -1:
            spans.append((pos, n))
            break
        spans.append((pos, nl + 1))
        pos = nl + 1
    return spans


def find_footnote_block_start(text: str) -> int | None:
    """문서 말미의 각주 모음 블록 시작 offset. 없으면 None.

    끝에서 역방향으로 훑으며 빈 줄은 통과, 각주 패턴 줄은 블록에 포함,
    그 외 줄을 만나면 중단. 최소 1개의 각주 줄이 있어야 블록으로 본다.
    """
    spans = _line_spans(text)
    start: int | None = None
    for ls, le in reversed(spans):
        line = text[ls:le]
        if not line.strip():
            continue
        if FOOTNOTE_LINE_RE.match(line):
            start = ls
            continue
        break
    return start


def _has_substantive(body: str, a: int, b: int) -> bool:
    """[a, b) 구간에 헤딩도 빈 줄도 아닌 실제 본문 줄이 있는가."""
    for ln in body[a:b].splitlines():
        if ln.strip() and not HEADING_LINE_RE.match(ln):
            return True
    return False


def _ends_with_heading(body: str, start: int, end: int) -> bool:
    region = body[start:end].rstrip()
    if not region:
        return False
    last_line = region.rsplit("\n", 1)[-1]
    return bool(HEADING_LINE_RE.match(last_line))


def _sentence_pieces(
    text: str, start: int, end: int, target: int
) -> list[tuple[int, int]]:
    """상한 초과 문단을 문장 경계에서 target 크기로 그리디 분할.

    경계가 아예 없는 초장 구간은 통짜로 반환한다(호출부가 경고).
    """
    bounds = [
        m.end() for m in _SENT_END_RE.finditer(text, start, end) if m.end() < end
    ]
    pieces: list[tuple[int, int]] = []
    piece_start = start
    prev: int | None = None
    for b in bounds:
        if b - piece_start > target:
            cut = prev if (prev is not None and prev > piece_start) else b
            pieces.append((piece_start, cut))
            piece_start = cut
            prev = b if b > cut else None
        else:
            prev = b
    if end - piece_start > target and prev is not None and prev > piece_start:
        pieces.append((piece_start, prev))
        piece_start = prev
    pieces.append((piece_start, end))
    return pieces


def _pack_segment(
    body: str,
    seg_start: int,
    seg_end: int,
    target: int,
    max_chunk: int,
    warnings: list[str],
) -> list[tuple[int, int]]:
    """헤딩 강제 컷 사이의 한 세그먼트를 문단 단위로 그리디 패킹."""
    # 문단 단위: 빈 줄 런의 *끝*에서 자르므로 각 청크는 문단 시작에서 출발하고
    # 구분 개행은 앞 청크 꼬리에 붙는다 (손실 없음).
    units: list[tuple[int, int]] = []
    pos = seg_start
    for m in _PARA_SEP_RE.finditer(body, seg_start, seg_end):
        if m.end() >= seg_end:
            break
        units.append((pos, m.end()))
        pos = m.end()
    if pos < seg_end:
        units.append((pos, seg_end))

    pieces: list[tuple[int, int]] = []
    for us, ue in units:
        if ue - us > SENT_SPLIT_TRIGGER_CHARS:
            subs = _sentence_pieces(body, us, ue, target)
            for ss, se in subs:
                # 문장 경계가 전혀 없는 통짜 런은 재조립 유실 검증의 사각지대라
                # 크기 상한과 무관하게 종전 4,000 기준으로 계속 경고한다.
                if se - ss > SENT_SPLIT_TRIGGER_CHARS and not _SENT_END_RE.search(
                    body, ss, se
                ):
                    warnings.append(
                        f"문장 경계로 쪼갤 수 없는 초장 구간 {se - ss}자 "
                        f"(offset {ss}) — 경고 기준({SENT_SPLIT_TRIGGER_CHARS}) "
                        f"초과 허용, 검토 요망"
                    )
            pieces.extend(subs)
        else:
            pieces.append((us, ue))

    chunks: list[tuple[int, int]] = []
    cur_start: int | None = None
    cur_end = 0
    for ps, pe in pieces:
        if cur_start is None:
            cur_start, cur_end = ps, pe
            continue
        would = (cur_end - cur_start) + (pe - ps)
        # 헤딩 글루: 현재 청크가 헤딩으로 끝나는 상태면 크기와 무관하게 이어붙여
        # "청크가 헤딩으로 끝남"을 구조적으로 금지한다.
        if would > target and not _ends_with_heading(body, cur_start, cur_end):
            chunks.append((cur_start, cur_end))
            cur_start, cur_end = ps, pe
        else:
            cur_end = pe
    if cur_start is not None:
        chunks.append((cur_start, cur_end))
    return chunks


def compute_chunk_spans(
    text: str,
    target: int = TARGET_CHUNK_CHARS,
    max_chunk: int = MAX_CHUNK_CHARS,
) -> tuple[list[dict], list[str]]:
    """원문을 손실 없이 청크 구간으로 나눈다. LLM 개입 0, 100% 결정적.

    반환: ([{start, end, passthrough}, ...], warnings)
    불변식 위반 시 ChunkingError.
    """
    warnings: list[str] = []
    if not text:
        return [], warnings

    fn_start = find_footnote_block_start(text)
    body_end = fn_start if fn_start is not None else len(text)

    spans: list[dict] = []
    if body_end > 0:
        body = text[:body_end]
        # 헤딩 강제 컷 수집. 직전 컷 이후 실제 본문이 없으면(연속 헤딩 런 등)
        # 컷을 억제해 헤딩으로 끝나는 청크를 만들지 않는다.
        cuts = [0]
        for ls, le in _line_spans(body):
            if ls == 0:
                continue
            if HEADING_LINE_RE.match(body[ls:le]) and _has_substantive(
                body, cuts[-1], ls
            ):
                cuts.append(ls)
        cuts.append(body_end)
        for seg_start, seg_end in zip(cuts, cuts[1:]):
            for cs, ce in _pack_segment(
                body, seg_start, seg_end, target, max_chunk, warnings
            ):
                spans.append({"start": cs, "end": ce, "passthrough": False})

    if fn_start is not None:
        spans.append({"start": fn_start, "end": len(text), "passthrough": True})

    # 후검: 크기 상한 / 말미 헤딩 (본문이 헤딩으로 끝나는 퇴화 문서만 해당).
    for i, sp in enumerate(spans, 1):
        size = sp["end"] - sp["start"]
        if not sp["passthrough"] and size > max_chunk:
            warnings.append(f"청크 {i} 크기 {size}자 — 상한({max_chunk}) 초과")
        if not sp["passthrough"] and _ends_with_heading(
            text, sp["start"], sp["end"]
        ):
            warnings.append(
                f"청크 {i}가 헤딩으로 끝남 — 뒤따르는 본문이 없는 문서 말미 헤딩"
            )

    # 최상위 불변식 self-check: 한 글자라도 어긋나면 fidelity 사고로 중단.
    joined = "".join(text[sp["start"] : sp["end"]] for sp in spans)
    if joined != text:
        raise ChunkingError(
            "lossless self-check failed: 청크 연결 결과가 원문과 불일치 "
            f"(원문 {len(text)}자, 연결 {len(joined)}자)"
        )
    return spans, warnings


def _render_chunk_header(index: int, total: int, starts_with_heading: bool) -> str:
    lines = [
        f"[청크 컨텍스트] 이 텍스트는 한 문서를 나눈 청크 {index}/{total}이다.",
        "- 문서 전체가 아니므로 서두·결말·전환 문구를 새로 만들지 말 것. "
        "경계가 잘린 듯 보여도 그대로 둔다.",
    ]
    if starts_with_heading:
        lines.append(
            "- 첫 줄은 제목/헤딩이다. 번호·기호·형식을 그대로 보존하고 "
            "본문 문장과 병합하지 말 것."
        )
    lines.append("")
    return "\n".join(lines)


def run_chunk_mode(args: argparse.Namespace, diagnosis: str | None) -> int:
    run_dir = _resolve_run_dir(args.run_dir, args.text, args.session_tag)
    input_path = run_dir / "01_input.txt"
    if args.text is not None:
        input_path.write_text(args.text, encoding="utf-8")
    if not input_path.exists():
        raise SystemExit(f"01_input.txt not found in {run_dir}; pass --text to create")
    text = _load_input(input_path, run_dir, not args.no_sanitize)
    if not text.strip():
        raise SystemExit("01_input.txt is empty; nothing to chunk")

    spans, warnings = compute_chunk_spans(text)

    # 전문(全文) 기준 route_hint — 청킹 경로가 애초에 적절했는지 manifest 에
    # 남긴다. 판정 실패는 청킹을 막지 않는다 (graceful degrade).
    route: dict | None = None
    if _metrics_mod is not None:
        try:
            full_metrics = _metrics_mod.compute_all(
                text, genre=args.genre, baseline_path=args.baseline
            )
            route = compute_route_hint(full_metrics)
        except Exception:  # noqa: BLE001 — 권고 산출 실패는 치명 아님.
            route = None
    if len(text) <= CHUNK_RECOMMEND_MIN_CHARS:
        warnings.append(
            f"입력 {len(text):,}자 ≤ 청킹 권장 최소 {CHUNK_RECOMMEND_MIN_CHARS:,}자 "
            f"— 단일 콜 실증 범위라 --chunk 비권장 (권고, route_hint 참조)"
        )

    # 재청킹은 이전 청크 산출물(경계가 달라진 02_* 윤문 결과 포함)을 무효화한다.
    # 낡은 파일이 재조립에 잘못 섞이는 사고를 막기 위해 지우고 시작한다.
    removed: list[str] = []
    for pattern in (
        "00_chunk_*",
        "01_chunk_*",
        "02_chunk_*_rewritten.txt",
        "03_reassembled.md",
        "03_reassembly_report.json",
    ):
        for stale in sorted(run_dir.glob(pattern)):
            stale.unlink()
            removed.append(stale.name)

    total = len(spans)
    entries: list[dict] = []
    degraded = 0
    for i, sp in enumerate(spans, 1):
        chunk_text = text[sp["start"] : sp["end"]]
        first_line = chunk_text.lstrip("\n").split("\n", 1)[0]
        starts_with_heading = not sp["passthrough"] and bool(
            HEADING_LINE_RE.match(first_line)
        )
        entry = {
            "index": i,
            "start": sp["start"],
            "end": sp["end"],
            "char_count": sp["end"] - sp["start"],
            "starts_with_heading": starts_with_heading,
            "heading": first_line.strip() if starts_with_heading else None,
            "passthrough": sp["passthrough"],
            "input_file": None,
            "rewritten_file": None,
        }
        if not sp["passthrough"]:
            entry["input_file"] = f"01_chunk_{i:02d}_input_with_metrics.txt"
            entry["rewritten_file"] = f"02_chunk_{i:02d}_rewritten.txt"

            metrics_obj: dict | None = None
            metrics_path = run_dir / f"00_chunk_{i:02d}_metrics.json"
            error_path = run_dir / f"00_chunk_{i:02d}_metrics.error"
            if _metrics_mod is None:
                error_path.write_text(
                    "metrics module import failed; chunk emitted without score block",
                    encoding="utf-8",
                )
                degraded += 1
            else:
                try:
                    metrics_obj = _metrics_mod.compute_all(
                        chunk_text, genre=args.genre, baseline_path=args.baseline
                    )
                    metrics_path.write_text(
                        json.dumps(metrics_obj, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except Exception as exc:  # noqa: BLE001 — graceful degrade.
                    metrics_obj = None
                    degraded += 1
                    error_path.write_text(
                        f"metrics_failed: {type(exc).__name__}: {exc}\n\n"
                        + traceback.format_exc(),
                        encoding="utf-8",
                    )
            combined = _render_chunk_header(
                i, total, starts_with_heading
            ) + _render_combined(chunk_text, metrics_obj, diagnosis=diagnosis)
            (run_dir / entry["input_file"]).write_text(combined, encoding="utf-8")
        entries.append(entry)

    manifest = {
        "version": 1,
        "created": date.today().isoformat(),
        "source_file": "01_input.txt",
        "source_chars": len(text),
        "source_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "genre": args.genre,
        "target_chunk_chars": TARGET_CHUNK_CHARS,
        "max_chunk_chars": MAX_CHUNK_CHARS,
        "route_hint": route["route_hint"] if route else None,
        "route_reason": route["route_reason"] if route else None,
        "chunk_count": total,
        "body_chunk_count": sum(1 for e in entries if not e["passthrough"]),
        "passthrough_chunk_count": sum(1 for e in entries if e["passthrough"]),
        "lossless_check": "ok",
        "warnings": warnings,
        "chunks": entries,
    }
    manifest_path = run_dir / "chunk_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    sizes = [e["char_count"] for e in entries]
    print(
        f"run_dir={run_dir}\n"
        f"manifest={manifest_path}\n"
        f"chunks={total} (body {manifest['body_chunk_count']} + "
        f"passthrough {manifest['passthrough_chunk_count']})\n"
        f"sizes={sizes}\n"
        f"route_hint={manifest['route_hint']}\n"
        f"metrics_degraded_chunks={degraded}\n"
        f"stale_removed={len(removed)}\n"
        f"warnings={len(warnings)}"
    )
    for w in warnings:
        print(f"WARNING: {w}")
    return 0


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Humanize KR v2.0 monolith input shim")
    p.add_argument("--run-dir", help="Existing run directory (relative ok)")
    p.add_argument("--text", help="Inline text input (creates new run dir)")
    p.add_argument(
        "--session-tag",
        default=None,
        help="run 디렉터리 이름 뒤에 붙는 세션 구분자(예: a3f9). 한 머신에서 여러 "
        "세션이 동시에 돌 때 _workspace/<날짜>-NNN 을 서로 덮어쓰는 사고를 막는다. "
        "--text 로 새 디렉터리를 만들 때만 쓰인다.",
    )
    p.add_argument("--genre", default="essay", help="Genre hint (default: essay)")
    p.add_argument(
        "--baseline",
        default=None,
        help="Override baseline JSON path (default: project default)",
    )
    p.add_argument(
        "--diagnosis",
        default=None,
        help="Path to a diagnosis text file; prepended before the metrics "
        "block (정밀 3콜 구조의 진단 1콜 산출물). Omit for legacy behaviour.",
    )
    p.add_argument(
        "--chunk",
        action="store_true",
        help="장문 청킹 모드: 01_input.txt 를 손실 없이 분할해 청크별 "
        "input_with_metrics 파일과 chunk_manifest.json 을 만든다.",
    )
    p.add_argument(
        "--no-sanitize",
        action="store_true",
        help="텍스트 위생 처리를 끈다. 기본은 켜짐 — 제로폭·특수공백·NFD 분해 한글 등 "
        "보이지 않는 오염을 01_input.txt 에 반영해 이후 게이트·diff 기준을 통일한다. "
        "(AI 워터마크와 무관 — scripts/sanitize_text.py 참조)",
    )
    args = p.parse_args(argv)

    diagnosis: str | None = None
    if args.diagnosis:
        diag_path = Path(args.diagnosis)
        if not diag_path.is_absolute():
            diag_path = Path.cwd() / diag_path  # --run-dir 과 같은 기준(cwd)
        if not diag_path.exists():
            raise SystemExit(f"--diagnosis file not found: {diag_path}")
        diagnosis = diag_path.read_text(encoding="utf-8")

    if args.chunk:
        return run_chunk_mode(args, diagnosis)

    run_dir = _resolve_run_dir(args.run_dir, args.text, args.session_tag)
    input_path = run_dir / "01_input.txt"

    # Ensure 01_input.txt exists.
    if args.text is not None:
        input_path.write_text(args.text, encoding="utf-8")
    if not input_path.exists():
        raise SystemExit(f"01_input.txt not found in {run_dir}; pass --text to create")

    text = _load_input(input_path, run_dir, not args.no_sanitize)

    metrics_obj: dict | None = None
    metrics_path = run_dir / "00_metrics.json"
    error_path = run_dir / "00_metrics.error"

    if _metrics_mod is None:
        error_path.write_text(
            "metrics module import failed; combined file emitted without score block",
            encoding="utf-8",
        )
    else:
        try:
            metrics_obj = _metrics_mod.compute_all(
                text, genre=args.genre, baseline_path=args.baseline
            )
            # v2.6 신형 티 계수는 원문이 필요하다 — 직렬화 전에 빼는 내부 키로 전달.
            metrics_obj["_text"] = text
            metrics_obj.update(compute_route_hint(metrics_obj))
            metrics_obj.pop("_text", None)
            metrics_path.write_text(
                json.dumps(metrics_obj, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            # On success any stale error file is cleared.
            if error_path.exists():
                try:
                    error_path.unlink()
                except OSError:
                    pass
        except Exception as exc:  # noqa: BLE001 — graceful degrade is the point.
            metrics_obj = None
            error_path.write_text(
                f"metrics_failed: {type(exc).__name__}: {exc}\n\n"
                + traceback.format_exc(),
                encoding="utf-8",
            )

    combined_path = run_dir / "01_input_with_metrics.txt"
    combined_path.write_text(
        _render_combined(text, metrics_obj, diagnosis=diagnosis), encoding="utf-8"
    )

    rb = (metrics_obj or {}).get("risk_band", "absent")
    rs = (metrics_obj or {}).get("risk_score", "absent")
    rh = (metrics_obj or {}).get("route_hint", "absent")
    print(
        f"run_dir={run_dir}\n"
        f"combined={combined_path}\n"
        f"risk_band={rb}  risk_score={rs}\n"
        f"route_hint={rh}\n"
        f"degraded={metrics_obj is None}"
    )
    return 0


# ── 콘솔 하드닝 (#84) ───────────────────────────────────────────────
# Windows(cp949)에서 한글·em-dash 출력이 UnicodeEncodeError 로 죽는 것을 막는다.
import os as _os  # noqa: E402
import sys as _sys  # noqa: E402

_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import console as _console  # noqa: E402

if __name__ == "__main__":
    _console.force_utf8_console()
    sys.exit(main())
