# Humanize KR — AI 한글 티 제거 하네스 (v2.3.2)

## 프로젝트 개요

AI(ChatGPT·Claude·Gemini 등)가 쓴 한글 텍스트를 "사람이 쓴 글처럼" 윤문해주는 3경로 하네스. 번역투·영어 인용 과다·기계적 병렬·관용구·피동태 남용·접속사 남발·리듬 균일성·이모지/불릿 과다 등 10대 카테고리 85개 AI 티 패턴(A-17 hold 1건 포함)을 탐지·분류해 **내용은 한 글자도 건드리지 않고** 문체·리듬·표현만 재작성한다.

v2.2부터 shim이 정량 점수로 산출하는 **`route_hint`(light | standard | heavy)** 가 디폴트 경로를 정한다(사용자 명시가 오버라이드). 글의 상태가 콜 수를 정하는 구조로, 구 "fast 1콜 / 정밀 3콜" 이분법을 대체한다.

v2.3부터 `verify_gates.py`가 문자율·진단 목표달성·대구 전멸·golden/수치의 4축을 검증한다. Codex도 같은 route_hint와 결정적 게이트를 사용해 light·standard·heavy 전체 경로를 제공한다.

- **light (1콜)** — 잘 쓴 글(어휘 티 거의 0). 진단·finalize 생략, 보수 강도 단일 윤문. 손댈 게 거의 없으면 "이미 좋습니다" 조기 종료.
- **standard (2콜)** — 보통의 AI 초안. 진단 1콜 + 겨냥 윤문 1콜. finalize 생략이 기본(결정적 변경률 게이트로 대체). 1만자급도 청킹 없이 단일 윤문 콜.
- **heavy (3+콜)** — 중증 AI 슬롭 밀집 or 초장문(15,000자 초과) or 검증 증적 필요. 진단 → 윤문(shim이 청크를 2개 이상 만든 경우에만 청크 병렬) → finalize. `--strict`·"정밀 모드"는 이 경로를 강제.

**콜 수 절감 원리** — 절감은 모델 티어가 아니라 콜 수에서 온다. 실측: 1만자 글 청킹 7콜 = 610K 토큰 vs 단일 콜 = 134K(품질 동등). 청크마다 룰북·진단이 재로드되는 비용이 폭발 원인. 따라서 **단일 콜 우선, 청킹은 heavy 전용·15,000자 이하 비권장.**

## 철칙

1. **의미 불변 (Fidelity First)** — 사실·주장·수치·고유명사·인용은 100% 원문 보존.
2. **근거 기반 (Span-Grounded)** — 모든 변경은 탐지 finding에 연결. 탐지 없는 구간은 건드리지 않음.
3. **장르 유지 (Tone Match)** — 칼럼을 문학으로, 리포트를 에세이로 옮기지 않음.
4. **과윤문 금지 (No Over-Polish)** — 변경률 30% 초과 시 경고, 50% 초과 시 강제 중단.
5. **register 보존 — 양방향** — 격식체 입력은 격식체 출력, 구어 입력은 구어 출력. 원문보다 딱딱하게 만들지 않는다: **'-했-' → '-하였-' 치환 금지**, '~인데요/~거든요/~한 겁니다' 구어 종결 보존. (하향 금지만 있던 기존 단방향 규칙으로는 합쇼체가 유지되는 '했→하였' 상향을 못 잡았다.) AI 티는 문법·수사이지 격식 자체가 아니다.
6. **AI 티는 빼기만 하고 넣지 않는다 (No New Tells)** — 원문에 없던 상투구("기록적인 성과를 거두었다"·"괄목할 만한"·"~로 평가된다") 신규 삽입 금지. 살아있는 구어는 사람 글의 증거이므로 보존한다. 철칙 #2가 "탐지 없는 구간은 손대지 않는다"라면, #6은 "손대는 구간에도 새 AI 티를 심지 않는다" — 모순이 아니라 보완이다.

## AI 워터마킹에 대한 입장 (2026-08-17 확정)

**배경.** Anthropic 은 2026-08-11 텍스트 워터마킹 도입을 발표했다. 방식은 Google DeepMind 의 **SynthID-Text** — 단어를 바꿔 심는 게 아니라, 동등하게 좋은 후보들 사이에서 뽑는 **난수의 출처**를 키 기반 결정값으로 바꾼다. EU AI Act 투명성 의무 대응이며 적용은 전 세계 동일. 2026-08-02 이후 출시 모델부터 적용되고, 그 이전 모델(Sonnet 5 = 6/30, Opus 5 = 7/24)에는 수개월에 걸쳐 소급 적용 중이다. **탐지 API 는 아직 공개되지 않았다.**

**결정: 워터마크 제거 기능은 탑재하지 않는다.**

1. **측정할 수 없다.** 탐지기가 없으므로 "지워졌는지"를 확인할 방법이 없다. 검증 없이 제거를 시도하면 맹목적으로 단어를 흔드는 것이고, 그건 이 프로젝트가 존재하는 이유(자연스러운 한국어)와 정면으로 충돌한다. 확실한 품질 손실을 지불하고 검증 불가능한 이득을 사는 거래다.
2. **투명성 장치 우회다.** EU AI Act 가 요구하는 출처 표시를 무력화하는 기능이다.
3. **선은 분명하다.** 어색한 한국어를 자연스럽게 고치는 편집이 부수적으로 통계 신호를 흐트러뜨리는 것은 이 프로젝트의 정상 동작이다. Anthropic 도 "전면 재작성이면 지워지고, 그 시점엔 AI 생성물이라 부를 수 있는지 자체가 논쟁적"이라고 인정했다. 금지되는 것은 그것을 **표적 기능으로 만들어 그렇게 광고하는 것**이다.

**따라서 `scripts/sanitize_text.py` 는 워터마크와 무관하다.** 제로폭 문자·특수 공백·NFD 분해 한글을 정리하는 텍스트 위생 도구일 뿐이며, SynthID 는 문자가 아니라 통계 패턴에 실리므로 문자 제거로는 애초에 건드릴 수 없다. 문서·UI 어디에서도 이 기능을 워터마크 제거로 표기하지 않는다.

**대신 하는 일: 계측.** 워터마킹이 한국어 품질에 실제로 영향을 주는지는 추측이 아니라 측정으로 답한다. `scripts/eval_baseline.py` 로 소급 적용 이전 지문을 떠 두고, 적용 이후 재촬영해 `scripts/eval_compare.py` 로 대조한다. 대조는 K회 반복의 자체 표준편차를 잡음 바닥으로 삼아 그걸 넘는 변화만 유의하다고 표시한다 (n=1 룰렛 금지).

## 디렉토리 구조

```
im-not-ai/
├── CLAUDE.md                      # 본 파일 — 프로젝트 가이드
├── README.md / INSTALL.md         # 사용·설치 안내
├── RELEASING.md                   # 릴리스 체크리스트 (버전 문자열 전수 + 글로벌 심링크 동기화)
├── CONTRIBUTORS.md
├── .claude-plugin/                # Claude 플러그인 + 마켓플레이스 매니페스트
│   ├── plugin.json                # skills: ./skills/ · 에이전트는 루트 agents/ 자동탐색
│   └── marketplace.json           # /plugin marketplace add epoko77-ai/im-not-ai
├── gemini-extension.json          # Gemini CLI Extension 매니페스트
├── GEMINI.md                      # Gemini 에이전트 컨텍스트 (monolith 룰 인라인)
├── commands/                      # Gemini CLI 커스텀 명령 (/humanize-korean, /humanize, /humanize-scan, /humanize-redo)
├── install.sh / uninstall.sh / update.sh   # Claude·Codex·Gemini 전역 설치/제거 (심링크 기본)
├── scripts/
│   ├── prepare_monolith_input.py  # input shim — 텍스트 위생 + 정량 점수 + route_hint 산출 + 결합 입력 (`--diagnosis`·`--chunk`·`--no-sanitize`)
│   ├── sanitize_text.py           # 텍스트 위생 — 제로폭·bidi·특수공백 제거 + 한글 NFD→NFC (결정적, LLM 0콜)
│   ├── eval_baseline.py           # 품질 기준선 촬영 — 픽스처 × 모델 × K회 반복 스냅샷
│   ├── eval_compare.py            # 스냅샷 2개 대조 — 자체 분산을 잡음 바닥 삼아 유의한 변화만 표시
│   ├── reassemble_chunks.py       # 장문 청킹 재조립 (passthrough 원문 삽입 + 문자수 대사)
│   ├── verify_gates.py            # v2.3 구조 수렴 게이트 — 문자율·목표달성·대구·golden/수치
│   ├── verify_change_rate.py      # 하위 호환 문자 변경률 게이트
│   ├── build_quick_rules.py       # taxonomy quick 메타 → quick-rules.md 빌드 (ID 드리프트 차단)
│   ├── build_social_preview_v2.py
│   └── make_thumbnail.py
├── tests/                         # pytest — metrics 단위 + 청킹 + 빌드 sync + golden 픽스처
│   ├── test_metrics.py · test_metrics_v2.py · test_chunking.py · test_quick_rules_build.py · test_sanitize.py
│   └── golden/                    # 윤문 품질 회귀 픽스처 + 결정적 채점기(checks.py)
├── agents/                        # 서브에이전트 9종 (플러그인 컨벤션 — 루트 agents/에 둬야 로드됨)
│   ├── humanize-monolith.md       # 전 경로 공용 윤문 콜
│   ├── humanize-diagnostician.md  # standard·heavy P1 진단 (지배 패턴 3~6개)
│   ├── humanize-finalizer.md      # heavy P3 마무리 (의미 15항 + 자연성)
│   ├── korean-ai-tell-taxonomist.md  # 유지보수 (SSOT 갱신)
│   └── … 개발용 지원 5종 (scholar·distiller·gap-analyzer·metric-engineer·integrator)
├── skills/                # 스킬 4종 (humanize-korean 오케스트레이터 + humanize·humanize-scan(정찰)·humanize-redo 진입)
│   └── humanize-korean/
│       ├── SKILL.md               # 오케스트레이터 (route_hint 3경로 분기·shim 배선, quick_rules_path: ${CLAUDE_SKILL_DIR}/...)
│       └── references/
│           ├── quick-rules.md          # monolith 슬림 룰북 (build_quick_rules.py가 taxonomy에서 생성)
│           ├── quick-rules.header.md · quick-rules.footer.md  # 빌드 고정 템플릿
│           ├── ai-tell-taxonomy.md     # SSOT — 10대분류 × 85 패턴(활성 84 + A-17 hold) (+ _quick 빌드 메타)
│           ├── rewriting-playbook.md   # 카테고리별 치환 레시피
│           ├── metrics.py · metrics_v2.py     # v1.6 8종 + v2.0 post-editese 14종
│           ├── baseline.json · baseline_v2.json   # v1.6 baseline · v2.0(placeholder — calibration 대기)
│           ├── scholarship.md          # v2.0 학술 인용 외부 SSOT
│           ├── roles/                  # Codex 런타임 역할 계약 3종
│           └── web-service-spec.md     # 웹 확장 스펙 (옵션)
├── codex/skills/humanize-korean/  # Codex 전체 경로 오케스트레이터
│   ├── SKILL.md                   # light·standard·heavy + 협업 에이전트/순차 폴백
│   ├── agents/openai.yaml         # Codex UI 메타데이터
│   ├── references → ../../../skills/humanize-korean/references
│   └── scripts/                   # 공용 런타임 스크립트 실행 래퍼
└── _workspace/                    # 런타임 산출물 (run_id별, gitignored)
    └── {YYYY-MM-DD-NNN-TAG}/          # TAG=세션 구분자(동시 실행 충돌 방지)
        ├── 01_input.txt · 00_metrics.json · 01_input_with_metrics.txt  # 원문·점수·결합
        ├── final.md                    # 윤문본 (끝에 <!-- HUMANIZE-SUMMARY --> 블록)
        ├── 01_chunk_{NN}… · 02_chunk_{NN}_rewritten.txt · 03_reassembled.md  # (장문 청킹)
        ├── 02_diagnosis.md             # (standard·heavy P1) 지배 패턴 진단
        ├── final_pre_finalize.md · 09_finalize.json   # (heavy P3) 백업 · 판정
```

## 파이프라인 (route_hint 3경로)

```
01_input.txt
    ↓ [scripts/prepare_monolith_input.py --run-dir _workspace/{run_id} --genre {genre}]
00_metrics.json (route_hint 포함) + 01_input_with_metrics.txt
    ↓ route_hint가 디폴트 경로 결정 (사용자 명시 --strict/"가볍게"가 오버라이드)
    │
    ├─ light ────→ [humanize-monolith ×1, 보수 강도] ──→ final.md
    │
    ├─ standard ─→ [humanize-diagnostician] → 02_diagnosis.md
    │                ↓ [shim --diagnosis] 진단+점수+원문 결합
    │              [humanize-monolith 겨냥 윤문] ──────→ final.md
    │
    └─ heavy ────→ [humanize-diagnostician] → 02_diagnosis.md
                     ↓ [shim --diagnosis] (청킹 필요 시에만 --chunk)
                   [humanize-monolith — shim이 청크 2+개 만든 경우에만 청크 병렬]
                     ↓ [verify_gates.py] (P2.5)
                   [humanize-finalizer — 의미 15항 + 자연성, 국소 보정]
                   final.md(보정) + 09_finalize.json
    ↓ [scripts/verify_gates.py — 구조 수렴 게이트 (exit code)] — 모든 경로 공통
```

- shim은 graceful degrade 내장 — metrics 실패 시 점수 블록 없는 결합 파일을 쓰고 `00_metrics.error`를 남긴다. 이 경우 route_hint 부재 → **standard로 간주**.
- **청킹 남발 금지** — `--chunk`는 heavy 전용, 15,000자 이하 비권장. 그때도 shim이 실제로 청크를 2개 이상 만들었을 때만 병렬(청크 1개면 단일 콜). 재조립은 `reassemble_chunks.py`.
- light·standard 결과가 등급 C/D면 heavy 재실행을 사용자에게 권고한다(자동 전환 아님 — opt-in).
- finalize의 `verdict=hold_and_report`면 사람 검토 권고. 수렴 판정은 LLM 재탐지가 아니라 `verify_gates.py`(결정적, exit code)가 내린다. `verify_change_rate.py`는 기존 연동을 위해 보존한다.

## 에이전트 구성 (9개 — 역할 구분 필수)

**런타임 3종** (스킬 실행 중 호출):

1. **humanize-monolith** — 전 경로 공용 윤문 콜. 한 콜에서 탐지·윤문·자체검증. 도구 호출 3회 캡 (v1.6.1).
2. **humanize-diagnostician** — standard·heavy P1 진단. 글 전체의 지배 패턴 3~6개를 본진 ID로 진단 → `02_diagnosis.md`.
3. **humanize-finalizer** — heavy P3 마무리. 원문 직접 대조로 의미 15항 + 자연성(잔존·과윤문 양방향) 판정, 문제 구간만 국소 보정 → `09_finalize.json`. 도구 호출 4회 캡.

**유지보수 1종** (별도 명령으로만):

4. **korean-ai-tell-taxonomist** — 분류 체계 SSOT 관리. 신규 패턴 심사·승격.

**개발용 1회성 5종** (v2.0 학술 흡수 회차 전용 — 윤문 런타임에 로드되지 않음):

5. **translationese-research-distiller** — 번역투 학술 보고서 구조화 증류.
6. **korean-translation-scholar** — 학술 인용 계보를 taxonomy + scholarship.md 양면 안착.
7. **taxonomy-gap-analyzer** — 외부 후보 풀 vs 본진 3축 갭 매핑.
8. **post-editese-metric-engineer** — post-editese 3축을 metrics_v2.py로 코드화.
9. **quick-rules-integrator** — v2.0 변경 묶음의 quick-rules 안착 + 캡 회귀 검증 + PR 준비.

**은퇴 (v2.1)**: 옛 strict 5인 파이프라인의 `ai-tell-detector`·`korean-style-rewriter`·`content-fidelity-auditor`·`naturalness-reviewer`와 웹 확장 설계용 `humanize-web-architect`는 v2.1에서 은퇴(정의 파일 삭제). 탐지·감사·리뷰 역할은 diagnostician·finalizer가 대체했고, v2.3부터 결정적 수렴 판정은 `verify_gates.py`가 담당한다.

## 심각도 기준

- **S1 결정적**: 한 번만 나와도 AI라고 확신하게 되는 패턴. 무조건 제거.
- **S2 강함**: 1~2회 허용, 3회+ 반복 시 제거.
- **S3 약함**: 다른 패턴과 중첩될 때만 문제.

## 품질 등급

- **A**: S1 0건, S2 2건 이하, score 개선 70%+
- **B**: S1 0건, S2 4건 이하, score 개선 50%+
- **C**: S1 1~2건 또는 과윤문 시그널 2개 — 2차 윤문
- **D**: S1 3건 이상 또는 심각한 과윤문 — 사람 검토

## 사용 방법

1. 새 세션에서 오케스트레이터 스킬 트리거:
   ```
   이 AI 글 자연스럽게 윤문해줘:
   ```
   (텍스트 첨부) — 또는 `/humanize` 슬래시 커맨드.
2. 디폴트는 shim의 `route_hint`가 정한다 — light 1콜 / standard 2콜 / heavy 3+콜. `--strict`·"정밀 모드"·부분 재실행은 heavy 강제, "가볍게"는 light 강제.
3. 결과: light는 `final.md` 1개(끝에 summary 주석 블록), standard는 + `02_diagnosis.md`, heavy는 + `09_finalize.json`·`final_pre_finalize.md`.

## 파일 시스템 접근 규칙

에이전트가 파일·디렉토리에 접근할 때는 전용 도구를 우선 사용한다.
`Bash` 툴의 `ls`·`cat`·`echo`는 실행 환경(OS·경로 형식)에 따라 동작이 달라져 예측 불가한 오류를 일으킬 수 있다. 예외: `prepare_monolith_input.py`(shim)·`verify_gates.py`(구조 수렴 게이트)·`verify_change_rate.py`(하위 호환)·`reassemble_chunks.py`(청킹 재조립) 실행은 Bash `python3` 호출이 정규 경로다.

| 작업 | 올바른 방법 | 피할 방법 |
|---|---|---|
| 파일 존재 확인 | `Glob` 도구 | `Bash` 툴 `ls` |
| 디렉토리 목록 열거 | `Glob` 도구로 안의 표지 파일 매칭 (예: `*/01_input.txt`) | `Bash` 툴 `ls` |
| 파일 읽기 | `Read` 도구 | `Bash` 툴 `cat` / `head` |
| 파일 쓰기·편집 | `Write` / `Edit` 도구 | `Bash` 툴 리다이렉션 |

## 주요 금기

- 수치·단위·날짜 변경 금지.
- 고유명사·제품명·모델명 변경 금지.
- 큰따옴표 인용문 내부 변경 금지.
- 법률 조문·학술 개념어 임의 치환 금지.
- 새로운 주장·사실·예시 추가 금지.
- 원문에 있던 정보 누락 금지.

## 릴리스

버전 문자열이 흩어져 있어 릴리스마다 누락 사고가 반복됐다 (v1.6.1·v2.0에서 SKILL.md 두 번 연속 누락). **릴리스 전 반드시 `RELEASING.md` 체크리스트를 따를 것.** 태그는 발행 노트·문서 갱신 커밋이 main에 머지된 뒤에 찍는다.

## 확장 포인트

- **웹 서비스화**: 별도 코드베이스로 라이브 (imnotai.kr). 본 리포의 `web-service-spec.md`는 설계 산출물로만 보존 (설계 에이전트 `humanize-web-architect`는 v2.1에서 은퇴).
- **다국어 확장**: 일본어·중국어로 확장 시 언어별 taxonomy 분리 파일 추가.
- **장르 확장**: 현재 4장르(칼럼·리포트·블로그·공적). 학술 논문·법률 문서·제품 카피 추가 가능.

## 참고

- 오케스트레이터: `skills/humanize-korean/SKILL.md`
- 분류 체계: `skills/humanize-korean/references/ai-tell-taxonomy.md`
- 윤문 처방: `skills/humanize-korean/references/rewriting-playbook.md`
- 슬림 룰북(monolith): `skills/humanize-korean/references/quick-rules.md`
- 학술 인용 SSOT: `skills/humanize-korean/references/scholarship.md`
- 웹 스펙: `skills/humanize-korean/references/web-service-spec.md`
