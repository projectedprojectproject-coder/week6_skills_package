"""윤문 전후의 마크다운을 비교해 내용이 바뀌지 않았는지 확인한다.

사용: python3 verify_edits.py 고치기전.md 고친뒤.md [--names 브람,세라,...] [--patterns 그녀,그러나,...]

확인하는 것
- 변경률: difflib 기준 문자 변경 비율
- 숫자: 고치기 전후에 나타나는 숫자의 개수 차이
- 제목: #으로 시작하는 줄이 모두 같은지
- 큰따옴표 안의 대사: 순서와 내용이 같은지
- 이름: --names에 준 이름 가운데 고친 뒤에 사라진 것
- 표현 빈도: --patterns에 준 표현이 고치기 전후 몇 번 나오는지

이번 작업에서는 이 검사들을 단계마다 짧은 인라인 스크립트로 따로 돌렸다.
이 파일은 그 검사들을 한데 모은 것이다.
"""
import argparse
import collections
import difflib
import re

p = argparse.ArgumentParser()
p.add_argument("before")
p.add_argument("after")
p.add_argument("--names", default="")
p.add_argument("--patterns", default="")
a = p.parse_args()

B = open(a.before, encoding="utf-8").read()
A = open(a.after, encoding="utf-8").read()

rate = 1 - difflib.SequenceMatcher(None, B, A, autojunk=False).ratio()
print(f"변경률: 약 {rate * 100:.1f}%")

nb = collections.Counter(re.findall(r"\d+", B))
na = collections.Counter(re.findall(r"\d+", A))
print("사라진 숫자:", dict(nb - na) or "없음")
print("새로 생긴 숫자:", dict(na - nb) or "없음")

hb = [l for l in B.splitlines() if l.startswith("#")]
ha = [l for l in A.splitlines() if l.startswith("#")]
print("제목 동일:", hb == ha)
if hb != ha:
    print("  바뀐 제목:", [x for x in hb if x not in ha], "->", [x for x in ha if x not in hb])

qb = re.findall(r'"[^"]+"', B)
qa = re.findall(r'"[^"]+"', A)
print("대사 동일:", qb == qa)
if qb != qa:
    print("  고치기 전에만 있음:", set(qb) - set(qa))
    print("  고친 뒤에만 있음:", set(qa) - set(qb))

if a.names:
    names = [n for n in a.names.split(",") if n]
    print("사라진 이름:", [n for n in names if n in B and n not in A] or "없음")

if a.patterns:
    for pat in [x for x in a.patterns.split(",") if x]:
        print(f"{pat}: {B.count(pat)} -> {A.count(pat)}")
